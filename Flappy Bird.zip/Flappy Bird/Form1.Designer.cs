﻿namespace Flappy_Bird
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.zemin = new System.Windows.Forms.PictureBox();
            this.downPipe = new System.Windows.Forms.PictureBox();
            this.upPipe = new System.Windows.Forms.PictureBox();
            this.flappyBird = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.gamePanel = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.zemin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.downPipe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upPipe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappyBird)).BeginInit();
            this.gamePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // zemin
            // 
            this.zemin.Image = ((System.Drawing.Image)(resources.GetObject("zemin.Image")));
            this.zemin.Location = new System.Drawing.Point(0, 555);
            this.zemin.Name = "zemin";
            this.zemin.Size = new System.Drawing.Size(884, 115);
            this.zemin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zemin.TabIndex = 0;
            this.zemin.TabStop = false;
            this.zemin.Click += new System.EventHandler(this.zemin_Click);
            // 
            // downPipe
            // 
            this.downPipe.Image = ((System.Drawing.Image)(resources.GetObject("downPipe.Image")));
            this.downPipe.Location = new System.Drawing.Point(621, 366);
            this.downPipe.Name = "downPipe";
            this.downPipe.Size = new System.Drawing.Size(100, 215);
            this.downPipe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.downPipe.TabIndex = 1;
            this.downPipe.TabStop = false;
            // 
            // upPipe
            // 
            this.upPipe.Image = ((System.Drawing.Image)(resources.GetObject("upPipe.Image")));
            this.upPipe.Location = new System.Drawing.Point(681, 0);
            this.upPipe.Name = "upPipe";
            this.upPipe.Size = new System.Drawing.Size(100, 179);
            this.upPipe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.upPipe.TabIndex = 2;
            this.upPipe.TabStop = false;
            // 
            // flappyBird
            // 
            this.flappyBird.Image = ((System.Drawing.Image)(resources.GetObject("flappyBird.Image")));
            this.flappyBird.Location = new System.Drawing.Point(33, 216);
            this.flappyBird.Name = "flappyBird";
            this.flappyBird.Size = new System.Drawing.Size(91, 71);
            this.flappyBird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flappyBird.TabIndex = 3;
            this.flappyBird.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(223)))), ((int)(((byte)(140)))));
            this.label1.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(733, 602);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "Score:0";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // gameTimer
            // 
            this.gameTimer.Enabled = true;
            this.gameTimer.Interval = 20;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimerEvent);
            // 
            // gamePanel
            // 
            this.gamePanel.Controls.Add(this.label1);
            this.gamePanel.Controls.Add(this.upPipe);
            this.gamePanel.Controls.Add(this.zemin);
            this.gamePanel.Controls.Add(this.flappyBird);
            this.gamePanel.Controls.Add(this.downPipe);
            this.gamePanel.Location = new System.Drawing.Point(-1, 0);
            this.gamePanel.Name = "gamePanel";
            this.gamePanel.Size = new System.Drawing.Size(887, 706);
            this.gamePanel.TabIndex = 5;
            this.gamePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Form1
            // 
            this.Appearance.BackColor = System.Drawing.Color.Cyan;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 670);
            this.Controls.Add(this.gamePanel);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "FlappyBird Game";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gamekeyisdown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gamekeyisup);
            ((System.ComponentModel.ISupportInitialize)(this.zemin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.downPipe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upPipe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappyBird)).EndInit();
            this.gamePanel.ResumeLayout(false);
            this.gamePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox zemin;
        private System.Windows.Forms.PictureBox downPipe;
        private System.Windows.Forms.PictureBox upPipe;
        private System.Windows.Forms.PictureBox flappyBird;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Panel gamePanel;
    }
}

