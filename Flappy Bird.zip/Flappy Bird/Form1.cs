﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Flappy_Bird
{
   
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        private float originalFormWidth;
        private float originalFormHeight;
        private Dictionary<Control, RectangleF> originalBounds = new Dictionary<Control, RectangleF>();
        private Dictionary<Control, float> originalFontSizes = new Dictionary<Control, float>();

        //Boruların ve kuşun ekranda hareket etme hızı.
        int boruHızı =8;
        // Space tuşuna basılmadığında yerçekimi etki ediyor.
        int Gravity = 15;
        // Score değeri 0 olarak başlıyor.Her boru geçişinde 1 artıyor.
        int score = 0;
        

        public Form1()
        {
            InitializeComponent();//Kontrollerin oluşmasını ve çalışmasını sağlar.
         
             this.Load += Form1_Load_1;// Form1 'i çalıştırır.
            this.Resize += Form1_Resize;// Form1 boyutunu günceller.

            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
            this.UpdateStyles();// Değişiklikleri günceller.

        }


        private void Form1_Load_1(object sender, EventArgs e)
        {
            originalFormWidth = this.Width;
            originalFormHeight = this.Height;
            StoreOriginalSizes(this);

       
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.KeyPreview = true;
           
        }
      

    private void StoreOriginalSizes(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                originalBounds[c] = new RectangleF(c.Left, c.Top, c.Width, c.Height);
                originalFontSizes[c] = c.Font?.Size ?? 0f;

               
                if (c is PictureBox pb)
                {
                    pb.SizeMode = PictureBoxSizeMode.StretchImage;//Eklenen resmin picturebox'a sığmasını sağlar.
                }

                if (c.Controls.Count > 0)//Formdaki kontrol sayısı 0'dan büyükse orjianl boyutunu
                    StoreOriginalSizes(c);//Kontrollerin orjinal boyut ve konumlarını kontrol eder.
            } }
        private void Form1_Resize(object sender, EventArgs e)//Oyun başlatıldığında form ve kontrollerin boyutunu ayarlar.
        {

            //Formun orjinal büyüklüğü ve genişliği 0'dan küçükse metottan çık.
            if (originalFormWidth <= 0 || originalFormHeight <= 0) return;

            // Formun mevcut genişliğinin orijinal genişliğe oranını hesaplar.
            float xRatio = (float)this.Width / originalFormWidth;
            // Formun mevcut yüksekliğinin orijinal yüksekliğe oranını hesaplar.
            float yRatio = (float)this.Height / originalFormHeight;

            ResizeAllControls(this, xRatio, yRatio);
        }
         private void ResizeAllControls(Control parent, float xRatio, float yRatio)
        {
            foreach (Control c in parent.Controls)
            {
                // originalBounds sözlüğünde c kontrolünün orijinal boyut ve konum bilgisi var mı diye kontrol eder.
                // Eğer varsa r değişkenine atar ve true döner
                if (originalBounds.TryGetValue(c, out RectangleF r))
                {
                    
                    c.Top = (int)(r.Top * yRatio);
                    c.Width = Math.Max(1, (int)(r.Width * xRatio));
                    c.Height = Math.Max(1, (int)(r.Height * yRatio));

                    
                    if (originalFontSizes.TryGetValue(c, out float originalFontSize) && originalFontSize > 0)
                    {
                        float newFontSize = originalFontSize * Math.Min(xRatio, yRatio);
                        try
                        {
                            c.Font = new Font(c.Font.FontFamily, Math.Max(1f, newFontSize), c.Font.Style);
                        }
                        catch
                        {
                           
                        }
                    }
                }

                
                if (c is PictureBox pb) pb.SizeMode = PictureBoxSizeMode.StretchImage;

                if (c.Controls.Count > 0)
                    ResizeAllControls(c, xRatio, yRatio);
            }
        }


        private void gameTimerEvent(object sender, EventArgs e)
        {
            //kuşun yerçekimi ile düşmesini sağlar.
            flappyBird.Top += Gravity;
            //Boruların sola doğru hareket etmesini sağlar.
            downPipe.Left -= boruHızı;
            upPipe.Left -= boruHızı;
            //Score'u ekrana yazdırır.
            label1.Text = $"score: {score}";
            ;
            if (downPipe.Left < -150)
            {// Aşağı boru ekranın solundan çıkarsa boruyu tekrar sağ tarafa getir ve skoru artırır.
                downPipe.Left = 800;
                score++;
            }
            if (upPipe.Left < -180)
            {// Yukarı boru ekranın solundan çıkarsa boruyu tekrar sağ tarafa getir ve skoru artırır.
                upPipe.Left = 950;
                score++;
            }
            if (flappyBird.Bounds.IntersectsWith(downPipe.Bounds) || flappyBird.Bounds.IntersectsWith(upPipe.Bounds) || flappyBird.Bounds.IntersectsWith(zemin.
                Bounds))
            {
                endgame();
            }
            if (score > 5)
            { // Skor belli bir seviyeyi geçtiyse boru hızını artırır. (oyun zorlaşır)
                boruHızı = 15;
            }
            if (flappyBird.Top < -25)
            {//Kuş ekranın üst sınırının üstüne çıkarsa oyunu bitirir.
                endgame();
            }
        }
         
        //Space tuşuna basıldığında kuşun yukarı doğru hareket etmesini sağlar.
        private void gamekeyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            
            {
                //Kuşun yukarı doğru hareket etmesi için yer çekimi negatif yapılır.
                Gravity=-15;

            }
        }
        //Space tuşuna basılmadığında çalışır.
        private void gamekeyisup(object sender, KeyEventArgs e)
        {
            //space tuşuna basılmadığında kuşun aşağı doğru hareket etmesi için yer çekimi pozitif olur.
            if (e.KeyCode == Keys.Space)
            {
                Gravity = 15;

            }
        }
        private void endgame()
        {
            gameTimer.Stop();//oyunu durdurur.
            label1.Text = "game over!!!";//Ekrana game over yazdırır.
        }
     
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void zemin_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

         

       
    }
}
